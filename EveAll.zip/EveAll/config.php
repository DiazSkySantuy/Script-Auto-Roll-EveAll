<?
/*gati bisa gak gati bisa*/
$user_agent = "Mozilla/5.0 (Linux; Android 7.1.2; Redmi 4A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Mobile Safari/537.36";

/*note=
waktu daftar email pass
wajip sama */
$email = "xxxxxx@gmail.com";
$pass = "xxxxx";


/*link pass  https://zagred.com/g5VRlP   */
$pass_scrip = "xxxxxxx";


